(function( $ ) {
    'use strict';

})( jQuery );
